from flask import Flask, request, jsonify
from pathlib import Path
import json
import secrets
app = Flask(__name__)
USERS_FILE = Path(__file__).parent / "users.json"
def loadUsers():
    try:
        return json.loads(USERS_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
@app.route("/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    username = data.get("username")
    password = data.get("password")
    if not username or not password:
        return jsonify({"success": False, "error": "Missing email or password"}), 400
    users = loadUsers()
    user = next((u for u in users if u.get("username") == username), None)
    if not user:
        return jsonify({"success": False, "error": "Invalid credentials"}), 401

    if user.get("password") != password:
        return jsonify({"success": False, "error": "Invalid credentials"}), 401
    token = secrets.token_urlsafe(32)
    return jsonify({"success": True, "token": token})
if __name__ == "__main__":
    app.run(debug=True)


